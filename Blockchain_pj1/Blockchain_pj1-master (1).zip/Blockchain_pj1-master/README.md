Please open `docs/index.html` in a web browser for documentation; we have also uploaded a copy on https://pdaian.com/cornellchain for your convenience!
