DB_PATH = "database/blockchain.db"

# don't change these; for problem 2
# (encoded as hex)
AUTHORITY_SK = "404a28d57118d33f7c59146f512b725b5f1336843ba1c8fe"
AUTHORITY_PK = "356c54fc3e57666eef27547ecf0257f8a27540ff7c145a2bcd8921d6e536f0208cbf98e220048d1e17e69dd587049e72"
