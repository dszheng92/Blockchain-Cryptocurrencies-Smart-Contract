if __name__ == '__main__':
    from webapp.app import app
    app.run(port=5000, debug=True)

